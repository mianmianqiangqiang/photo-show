<template>
	<div id="home">
		<app-header v-on:titleChanged="updateTitle($event)" v-bind:title="title"></app-header>
		<users v-bind:users="users"></users>
		<users v-bind:users="users"></users>
		<app-footer v-bind:title="title"></app-footer>
	</div>
</template>

<script>
	//局部注册文件
	import Users from './Users'
	import Header from './Header'
	import Footer from './Footer'
	export default {
		name: 'home',
		data() {
			return {
				users: [{
						name: "李四",
						position: "挖矿工",
						show: false
					},
					{
						name: "李四",
						position: "挖矿工",
						show: false
					},
					{
						name: "李四",
						position: "挖矿工",
						show: false
					},
					{
						name: "李四",
						position: "挖矿工",
						show: false
					},
					{
						name: "李四",
						position: "挖矿工",
						show: false
					},
					{
						name: "李四",
						position: "挖矿工",
						show: false
					}
				],
				title: "这是一个传值(string,Number,布尔)"
			}

		},
		methods: {
			updateTitle: function(title) {
				//		this.title="changed"
				this.title = title
			}
		},
		components: {
			"users": Users,
			"app-header": Header,
			"app-footer": Footer
		}
	}
</script>

<style scoped="">
	h1 {
		color: yellow;
	}
</style>