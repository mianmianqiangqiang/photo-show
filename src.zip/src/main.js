// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import HelloWorld from './components/HelloWorld'
import Home from './components/Home'
//import router from './router'
import Router from 'vue-router'
//import Users from './components/Users'
//css---导入
import '../static/css/hero-slider-style.css'
import '../static/css/magnific-popup.css'
import '../static/css/templatemo-style.css'
import '../static/css/bootstrap.min.css'
//js ---引入
import jquery from '../static/js/jquery-1.11.3.min'
//import '../static/js/bootstrap.min.js'
//import '../static/js/hero-slider-main.js'
//import '../static/js/jquery.magnific-popup.min.js'

//import '../static/js/tether.min.js'
//import '../static/js/new_file.js'


Vue.use(Router)
Vue.config.productionTip = false
//全局注册组件
//Vue.component("users",Users);
const router= new Router({
routes: [
    {path: '/',component: Home},
    {path: '/helloworld',component: HelloWorld}
],
mode:"history"
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
